﻿#powershell -file create-update-vpc.ps1 "AKIAI624QOOFLFRT2B5Q" "g6qurmiuUugcAs9yHLHXvJhee2iKaMolRHx1VkEa" "us-east-1"
$aws_key=$args[0]
$aws_secret=$args[1]
$aws_region=$args[2]
#Store state in S3
terraform remote config -backend="s3" -backend-config="bucket=ae-terraform-state-prod" -backend-config="key=ppas/nonprod/vpc/uatsubnet/terraform.tfstate" -backend-config="region=$aws_region" -backend-config="access_key=$aws_key" -backend-config="secret_key=$aws_secret" -backend-config="acl=authenticated-read"
# Run plan then apply
terraform get
terraform plan -var "aws_access_key=$aws_key" -var "aws_secret_key=$aws_secret" -var "aws_region=$aws_region" -module-depth=-1
terraform apply -var "aws_access_key=$aws_key" -var "aws_secret_key=$aws_secret" -var "aws_region=$aws_region"
