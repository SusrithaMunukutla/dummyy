﻿#powershell -file create-update-vpc.ps1 "KIAI624QOOFLFRT2B5Q" "g6qurmiuUugcAs9yHLHXvJhee2iKaMolRHx1VkEa" "us-east-1"
#AWS Access Key
$aws_key=$args[0]
#AWS Secret Key
$aws_secret=$args[1]
#AWS Region
$aws_region=$args[2]

terraform remote config -backend="s3" -backend-config="bucket=ae-devops-repo" -backend-config="key=ppas/nonprod/vpc/terraform.tfstate" -backend-config="region=$aws_region" -backend-config="access_key=$aws_key" -backend-config="secret_key=$aws_secret"
terraform get
#Execute Plan
terraform plan -var "aws_access_key=$aws_key" -var "aws_secret_key=$aws_secret" -var "aws_region=$aws_region"
#Execute Destroy
terraform destroy -var "aws_access_key=$aws_key" -var "aws_secret_key=$aws_secret" -var "aws_region=$aws_region" -force
