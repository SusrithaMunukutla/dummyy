<powershell>
# Setup IIS
mkdir C:\temp\n1
Import-Module ServerManager

Add-WindowsFeature -Name Web-Common-Http,Web-Asp-Net

Import-Module WebAdministration
mkdir C:\temp\n2
# Restart IIS
$Command = "IISRESET"

Invoke-Expression -Command $Command

Copy-Item -Path C:\inetpub\wwwroot\* -Destination C:\inetpub\wwwroot3

#Setup new web site in IIS
New-WebSite -Name "TestSite3" -Port 80 -HostHeader "localhost" -PhysicalPath "C:\inetpub\wwwroot3" -Force
mkdir C:\temp\n3

# Connect to AWS using Key and secret
$accessKey = "AKIAJFI7YVVAKCTRY3AA"
# Your account secret access key
$secretKey = "IDTz2mdy+GUQIU9Q4wOuSPz//Fws0giGT7Ur3XwF"
$region = "us-east-1"

Import-Module "C:\Program Files\AWS Tools\PowerShell\AWSPowerShell\AWSPowerShell.psd1" 

# Get code deploy agent and install it
mkdir C:\temp\n4
Read-S3Object -BucketName aws-codedeploy-us-east-1 -Key latest/codedeploy-agent.msi -File c:\temp\codedeploy-agent.msi -AccessKey $accessKey -SecretKey $secretKey -Region $region
c:\temp\codedeploy-agent.msi /quiet /l c:\temp\host-agent-install-log.txt

Start-Sleep -Seconds 20
# Check code deploy agent installed or not
Get-Service -Name codedeployagent

mkdir C:\temp\n5

</powershell>