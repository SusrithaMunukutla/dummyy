﻿#powershell -file create.ps1 "AKIAI624QOOFLFRT2B5Q" "g6qurmiuUugcAs9yHLHXvJhee2iKaMolRHx1VkEa" "us-east-1" "PANDA-AENETWORKS"
$aws_key=$args[0]
$aws_secret=$args[1]
$aws_region=$args[2]
$aws_key_name=$args[3]
$s3_rstate_bucket_key=$args[4]
$s3_rstate_bucket_secret=$args[5]
#If terraform_apply is yes then apply the changes 
$terraform_apply=$args[6]
#Parameter for bootstrap
$ppas_ou=$args[7]
$ppas_domain_user=$args[8]
$ppas_domain_pwd=$args[9]

#Store state in S3
terraform remote config -backend="s3" -backend-config="bucket=ae-ppas-terraform-state" -backend-config="key=ppas/nonprod/dev/panda2/terraform.tfstate" -backend-config="region=$aws_region" -backend-config="access_key=$aws_key" -backend-config="secret_key=$aws_secret"

# Run plan then apply 
terraform get
terraform plan -var "aws_access_key=$aws_key" -var "aws_secret_key=$aws_secret" -var "aws_region=$aws_region" -var="aws_key_name=$aws_key_name" -var "s3_rstate_bucket_key=$s3_rstate_bucket_key" -var "s3_rstate_bucket_secret=$s3_rstate_bucket_secret" -var "ppas_ou=$ppas_ou" -var "ppas_domain_user=$ppas_domain_user" -var "ppas_domain_pwd=$ppas_domain_pwd" -module-depth=-1

If ($terraform_apply -eq "yes") {
	terraform apply -var "aws_access_key=$aws_key" -var "aws_secret_key=$aws_secret" -var "aws_region=$aws_region" -var="aws_key_name=$aws_key_name" -var "s3_rstate_bucket_key=$s3_rstate_bucket_key" -var "s3_rstate_bucket_secret=$s3_rstate_bucket_secret" -var "ppas_ou=$ppas_ou" -var "ppas_domain_user=$ppas_domain_user" -var "ppas_domain_pwd=$ppas_domain_pwd"
}