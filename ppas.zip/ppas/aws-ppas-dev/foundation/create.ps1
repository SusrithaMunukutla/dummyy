﻿#powershell -file create.ps1 "12345" "g6qurmiuUugcAs9yHLHXvJhee2iKaMolRHx1VkEa" "us-east-1"
$aws_key=$args[0]
$aws_secret=$args[1]
$aws_region=$args[2]
$s3_rstate_bucket_key=$args[3]
$s3_rstate_bucket_secret=$args[4]
#If terraform_apply is yes then apply the changes 
$terraform_apply=$args[5]
#Store state in S3
terraform remote config -backend="s3" -backend-config="bucket=ae-ppas-terraform-state" -backend-config="key=ppas/nonprod/dev/foundation/terraform.tfstate" -backend-config="region=$aws_region" -backend-config="access_key=$aws_key" -backend-config="secret_key=$aws_secret"
# Run plan then apply 
terraform get
terraform plan -var "aws_access_key=$aws_key" -var "aws_secret_key=$aws_secret" -var "aws_region=$aws_region" -var "s3_rstate_bucket_key=$s3_rstate_bucket_key" -var "s3_rstate_bucket_secret=$s3_rstate_bucket_secret" -module-depth=-1
If ($terraform_apply -eq "yes") {
	terraform apply -var "aws_access_key=$aws_key" -var "aws_secret_key=$aws_secret" -var "aws_region=$aws_region" -var "s3_rstate_bucket_key=$s3_rstate_bucket_key" -var "s3_rstate_bucket_secret=$s3_rstate_bucket_secret"
}